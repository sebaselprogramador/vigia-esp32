"""ESP32 por USB -> Firebase. Compatible con la salida serie del sketch recibido."""
import argparse
import getpass
import json
import re
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

LINE = re.compile(r"^Temp:\s*(-?\d+(?:[.,]\d+)?)\s*C\s*\|\s*Gas crudo:\s*(\d+)\s*\|\s*Estado:\s*(ALERTA|normal)\s*$")


def parse_reading(line, timestamp=None):
    match = LINE.fullmatch(line.strip())
    if not match:
        return None
    temperature, gas, state = match.groups()
    temperature, gas = float(temperature.replace(',', '.')), int(gas)
    if not -55 <= temperature <= 150 or not 0 <= gas <= 4095:
        return None
    alarm = state == 'ALERTA'
    return dict(temperatureC=temperature, gasRaw=gas,
                timestamp=timestamp or int(time.time() * 1000), alarm=alarm,
                buzzer=alarm, pump1=alarm, pump2=alarm)


def cause(row):
    gas, heat = row['gasRaw'] >= 2200, row['temperatureC'] >= 47.5
    return 'both' if gas and heat else 'gas' if gas else 'temperature' if heat else None


class Journal:
    """Cola y episodio activo en una transacción: reintentos sin duplicar registros."""
    def __init__(self, path, device):
        self.db = sqlite3.connect(path, check_same_thread=False, timeout=15)
        self.db.execute('CREATE TABLE IF NOT EXISTS queue (id INTEGER PRIMARY KEY, payload TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
        self.db.commit()
        self.lock = threading.Lock()
        existing = self.db.execute("SELECT value FROM state WHERE key='device'").fetchone()
        if existing and json.loads(existing[0]) != device:
            raise ValueError('La cola pertenece a otro dispositivo. Usa otro archivo --queue.')
        self.db.execute("INSERT OR REPLACE INTO state VALUES ('device', ?)", (json.dumps(device),))
        self.db.commit()

    def accept(self, row):
        with self.lock, self.db:
            saved = self.db.execute("SELECT value FROM state WHERE key='episode'").fetchone()
            episode = json.loads(saved[0]) if saved else None
            sampled = self.db.execute("SELECT value FROM state WHERE key='sampled'").fetchone()
            last_sample = int(json.loads(sampled[0])) if sampled else 0
            changed = bool(episode) != row['alarm']
            payload = {'current': row}
            if changed or row['timestamp'] - last_sample >= 30000 or row['timestamp'] < last_sample:
                sample = {k: row[k] for k in ('temperatureC', 'gasRaw', 'timestamp')}
                payload['samples/' + uuid.uuid4().hex] = sample
                self.db.execute("INSERT OR REPLACE INTO state VALUES ('sampled', ?)", (json.dumps(row['timestamp']),))
            if row['alarm']:
                if episode is None:
                    # La primera lectura puede corresponder a una alarma ya iniciada.
                    episode = dict(id=uuid.uuid4().hex, startedAt=row['timestamp'],
                                   reason=cause(row) or 'both', peakTemperatureC=row['temperatureC'], peakGasRaw=row['gasRaw'])
                episode['peakTemperatureC'] = max(episode['peakTemperatureC'], row['temperatureC'])
                episode['peakGasRaw'] = max(episode['peakGasRaw'], row['gasRaw'])
                new_cause = cause(row)
                if new_cause and new_cause != episode['reason']:
                    episode['reason'] = 'both'
                payload['events/' + episode['id']] = {k: v for k, v in episode.items() if k != 'id'}
            elif episode:
                payload['events/' + episode['id']] = {k: v for k, v in episode.items() if k != 'id'} | {'endedAt': row['timestamp']}
                episode = None
            self.db.execute("INSERT OR REPLACE INTO state VALUES ('episode', ?)", (json.dumps(episode),))
            self.db.execute('INSERT INTO queue(payload) VALUES (?)', (json.dumps(payload),))

    def first(self):
        with self.lock:
            return self.db.execute('SELECT id, payload FROM queue ORDER BY id LIMIT 1').fetchone()

    def acknowledge(self, identifier):
        with self.lock, self.db:
            self.db.execute('DELETE FROM queue WHERE id=?', (identifier,))

    def count(self):
        with self.lock:
            return self.db.execute('SELECT COUNT(*) FROM queue').fetchone()[0]

    def close(self):
        self.db.close()


class Firebase:
    def __init__(self, api_key, database_url, device, email, password):
        self.api_key, self.database_url, self.device = api_key, database_url.rstrip('/'), device
        self.email, self.password = email, password
        self.token = self.refresh_token = None
        self.expires = 0

    @staticmethod
    def request(url, data, method='POST', form=False):
        body = urllib.parse.urlencode(data).encode() if form else json.dumps(data).encode()
        request = urllib.request.Request(url, data=body, method=method,
                                         headers={'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json'})
        with urllib.request.urlopen(request, timeout=15) as response:
            return json.load(response)

    def authenticate(self):
        if self.token and time.monotonic() < self.expires:
            return
        if self.refresh_token:
            result = self.request('https://securetoken.googleapis.com/v1/token?key=' + urllib.parse.quote(self.api_key),
                                  {'grant_type': 'refresh_token', 'refresh_token': self.refresh_token}, form=True)
            self.token, self.refresh_token = result['id_token'], result['refresh_token']
            self.expires = time.monotonic() + int(result['expires_in']) - 60
        else:
            result = self.request('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + urllib.parse.quote(self.api_key),
                                  {'email': self.email, 'password': self.password, 'returnSecureToken': True})
            self.token, self.refresh_token = result['idToken'], result['refreshToken']
            self.expires = time.monotonic() + int(result['expiresIn']) - 60
            print('Sesión Firebase iniciada. UID del puente:', result['localId'], flush=True)

    def send(self, payload):
        self.authenticate()
        url = f'{self.database_url}/devices/{self.device}.json?auth=' + urllib.parse.quote(self.token)
        try:
            self.request(url, payload, method='PATCH')
        except urllib.error.HTTPError as error:
            if error.code == 401:
                self.expires = 0
            raise


def sender(journal, firebase, stop):
    failures = 0
    while not stop.is_set():
        pending = journal.first()
        if not pending:
            stop.wait(.2)
            continue
        try:
            firebase.send(json.loads(pending[1]))
            journal.acknowledge(pending[0])
            if failures:
                print('Envío recuperado. Registros pendientes:', journal.count(), flush=True)
            failures = 0
        except (urllib.error.URLError, TimeoutError, OSError, ValueError, KeyError) as error:
            failures += 1
            # No imprimir URL/objeto de excepción: puede contener el token de sesión.
            code = getattr(error, 'code', None)
            print(f'Envío pendiente (HTTP {code or "sin respuesta"}). Revisa Internet, usuario y reglas. Cola: {journal.count()}', flush=True)
            stop.wait(min(30, 2 ** min(failures, 5)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', help='Puerto COM; si se omite muestra una lista')
    parser.add_argument('--list-ports', action='store_true')
    parser.add_argument('--queue', default=str(Path.home() / '.vigia-esp32' / 'queue.sqlite3'))
    parser.add_argument('--config', default=str(Path(__file__).with_name('config.json')))
    args = parser.parse_args()
    try:
        import serial
        from serial.tools import list_ports
    except ImportError:
        raise SystemExit('Instala la dependencia: py -m pip install -r requirements.txt')
    ports = list(list_ports.comports())
    if args.list_ports:
        for port in ports:
            print(port.device, '-', port.description)
        return
    if not args.port:
        if not ports:
            raise SystemExit('No hay puertos. Conecta el ESP32 con un cable de datos y vuelve a iniciar.')
        for i, port in enumerate(ports, 1):
            print(f'{i}. {port.device} - {port.description}')
        try:
            choice = int(input('Selecciona el número del ESP32: '))
            if not 1 <= choice <= len(ports):
                raise ValueError()
            args.port = ports[choice - 1].device
        except ValueError:
            raise SystemExit('Selección de puerto inválida.')
    config = json.loads(Path(args.config).read_text(encoding='utf-8-sig'))
    if not re.fullmatch(r'[A-Za-z0-9_-]+', config['deviceId']):
        raise SystemExit('deviceId inválido.')
    url = urllib.parse.urlsplit(config['databaseURL'])
    if url.scheme != 'https' or not url.hostname or not url.hostname.endswith(('.firebaseio.com', '.firebasedatabase.app')):
        raise SystemExit('databaseURL debe ser una URL HTTPS de Firebase Realtime Database.')
    email = input('Correo del usuario PUENTE/ESP32 en Firebase: ').strip()
    password = getpass.getpass('Contraseña (no se muestra ni guarda): ')
    Path(args.queue).parent.mkdir(parents=True, exist_ok=True)
    journal = Journal(args.queue, config['deviceId'])
    firebase = Firebase(config['apiKey'], config['databaseURL'], config['deviceId'], email, password)
    stop = threading.Event()
    worker = threading.Thread(target=sender, args=(journal, firebase, stop), daemon=True)
    worker.start()
    print('Cierra el monitor serie de Arduino IDE. El ESP32 mantiene su control local.', flush=True)
    try:
        while not stop.is_set():
            try:
                with serial.Serial(args.port, 115200, timeout=1) as connection:
                    connection.reset_input_buffer()
                    print('Leyendo USB:', args.port, flush=True)
                    buffer = b''
                    while not stop.is_set():
                        buffer += connection.read_until(b'\n', size=1024)
                        while b'\n' in buffer:
                            line, buffer = buffer.split(b'\n', 1)
                            row = parse_reading(line.decode('utf-8', errors='replace'))
                            if row:
                                journal.accept(row)
                                print(f'Temp: {row["temperatureC"]:.1f} C | MQ-7: {row["gasRaw"]} | {"ALERTA" if row["alarm"] else "normal"} | pendientes: {journal.count()}', flush=True)
                        if len(buffer) > 4096:
                            buffer = b''
            except serial.SerialException:
                print('USB no disponible. Cierra el monitor serie y revisa el cable. Reintento en 3 s.', flush=True)
                stop.wait(3)
    except KeyboardInterrupt:
        print('\nDeteniendo. Los registros pendientes quedan guardados para el próximo inicio.')
    finally:
        stop.set()
        worker.join(timeout=20)
        if not worker.is_alive():
            journal.close()


if __name__ == '__main__':
    main()
