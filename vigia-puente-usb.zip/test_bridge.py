import json
import tempfile
import unittest
from pathlib import Path
from bridge import Journal, parse_reading


class BridgeTests(unittest.TestCase):
    def test_existing_sketch_output(self):
        row = parse_reading('Temp: 48.0 C | Gas crudo: 2500 | Estado: ALERTA', 1000)
        self.assertTrue(row['pump1'])
        self.assertEqual(row['temperatureC'], 48)
        self.assertIsNone(parse_reading('>>> ALERTA activada por: GAS <<<'))
        self.assertIsNone(parse_reading('Temp: 48 C | Gas crudo: 8000 | Estado: ALERTA'))

    def test_episode_peaks_and_durable_retry(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            path = str(Path(folder) / 'queue.sqlite3')
            journal = Journal(path, 'esp32-01')
            journal.accept(parse_reading('Temp: 30.0 C | Gas crudo: 2400 | Estado: ALERTA', 1000))
            first = journal.first()
            event_path = next(k for k in json.loads(first[1]) if k.startswith('events/'))
            journal.acknowledge(first[0])
            journal.accept(parse_reading('Temp: 53.0 C | Gas crudo: 2000 | Estado: ALERTA', 2000))
            journal.close()
            journal = Journal(path, 'esp32-01')
            journal.accept(parse_reading('Temp: 28.0 C | Gas crudo: 800 | Estado: normal', 3000))
            saved = json.loads(journal.first()[1])
            self.assertEqual(saved[event_path]['reason'], 'both')
            self.assertEqual(saved[event_path]['peakTemperatureC'], 53)
            self.assertEqual(saved[event_path]['peakGasRaw'], 2400)
            journal.acknowledge(journal.first()[0])
            final = json.loads(journal.first()[1])
            self.assertEqual(final[event_path]['endedAt'], 3000)
            self.assertTrue(any(k.startswith('samples/') for k in final))
            self.assertFalse(final['current']['pump1'])
            journal.close()

    def test_sample_cadence_does_not_lose_peak(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            journal = Journal(str(Path(folder) / 'q.sqlite3'), 'esp32-01')
            journal.accept(parse_reading('Temp: 48.0 C | Gas crudo: 1000 | Estado: ALERTA', 1000))
            journal.acknowledge(journal.first()[0])
            journal.accept(parse_reading('Temp: 60.0 C | Gas crudo: 1100 | Estado: ALERTA', 2000))
            payload = json.loads(journal.first()[1])
            self.assertFalse(any(k.startswith('samples/') for k in payload))
            event = next(v for k, v in payload.items() if k.startswith('events/'))
            self.assertEqual(event['peakTemperatureC'], 60)
            journal.close()


if __name__ == '__main__':
    unittest.main()
