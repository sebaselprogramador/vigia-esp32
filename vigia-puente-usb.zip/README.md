# Enviar las lecturas USB a Firebase

El Arduino IDE carga el sketch en el ESP32. El puente de esta carpeta lee el
puerto serie y envía las lecturas a Firebase con el Internet de la computadora.
El ESP32 no necesita Wi-Fi. El puente muestra las lecturas en su propia ventana.
No puede compartir el puerto COM con el monitor serie de Arduino IDE.

## Preparar una vez, en la computadora donde está conectado el ESP32

1. Instala Python desde https://www.python.org/downloads/windows/ si no lo tienes.
2. Ejecuta `instalar.cmd`. Instala pySerial desde el registro de Python.
3. En Firebase Authentication activa correo/contraseña y crea un usuario para
   el puente (puede ser el usuario que antes llamábamos ESP32).
4. Crea otro usuario para entrar a la web. Copia sus UID en `database.rules.json`:
   `REEMPLAZAR_UID_ESP32` = UID del puente; `REEMPLAZAR_UID_VISOR` = UID del visor.
   Publica esas reglas en Realtime Database. No abras escritura pública.
5. Conserva el sketch Arduino que compartiste: el puente entiende su salida:

```text
Temp: 28.4 C | Gas crudo: 930 | Estado: normal
Temp: 50.0 C | Gas crudo: 2500 | Estado: ALERTA
```

Si cambias el formato o la lógica de control, ajusta el puente. Los estados de
buzzer y bombas se deducen de `Estado` porque tu sketch los cambia juntos.
No hay confirmación de flujo de agua. La precisión de temperatura guardada es
la que imprime tu sketch (un decimal).

## Usar cada vez

1. Conecta el ESP32 por USB. Puedes usar Arduino IDE para cargar el sketch.
2. **Cierra el monitor serie y el graficador serie**. Puedes dejar el IDE abierto.
3. Ejecuta `iniciar.cmd`, selecciona el ESP32 de la lista e introduce el correo
   y contraseña del usuario del puente. No necesitas conocer previamente el COM.
4. Mantén esta ventana abierta y la computadora encendida/conectada a Internet.
5. Inicia sesión en la web con la cuenta del visor. Recibirá los cambios de Firebase.

La contraseña se solicita sin mostrarla y no se guarda. No nos envíes contraseñas.
El puente usa Firebase Authentication y REST, con las reglas del usuario,
sin claves de servicio ni privilegios de administrador.

## Qué registra

- Estado actual: cada lectura completa, normalmente una por segundo.
- Muestras para la gráfica: cada 30 segundos y al comenzar/terminar una alarma.
- Un episodio por alarma con inicio, fin, motivo y máximos de todas las lecturas.
  El inicio es la primera alarma **observada por el puente**, no necesariamente
  el instante real de activación si el puente empezó después o hubo una desconexión.
- Fechas tomadas del reloj de Windows. Mantén la hora de la computadora sincronizada.
- La cola y el episodio activo quedan en `%USERPROFILE%\.vigia-esp32\queue.sqlite3`.

Si Internet falla, sigue leyendo USB y guarda una cola local. Al recuperarse,
reenvía en orden con IDs estables para no duplicar muestras/eventos. Mientras
recupera una cola antigua, el panel puede indicar datos antiguos. No se pueden
recuperar lecturas durante períodos en que el puente no estaba ejecutándose o
el USB estaba desconectado. Un episodio abierto se conserva hasta recibir una
lectura normal; puede incluir un período sin observaciones. El ESP32 nunca espera
al puente para controlar los actuadores.

## Comprobar

Al iniciar sesión, el puente imprime su UID. Si ves HTTP 400, revisa que
Authentication esté habilitado y que el correo, contraseña y apiKey sean correctos.
HTTP 401/403 puede indicar que las reglas todavía no autorizan al usuario.
Sin respuesta: revisa Internet. Durante estos errores los registros quedan pendientes.

En Firebase debe aparecer `devices/esp32-01/current`, `samples` y `events`.
Solo puede verificarse el circuito completo con el ESP32 y una cuenta autorizada.
La web aún requiere publicación para poder abrirla desde otro dispositivo.

Pruebas sin USB ni Firebase: `py -m unittest discover -s . -p "test_*.py"`.

Documentación: https://pyserial.readthedocs.io/en/latest/ y
https://firebase.google.com/docs/reference/rest/auth y
https://firebase.google.com/docs/database/rest/save-data.
