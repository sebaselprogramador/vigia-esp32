# ESP32 directo a Firebase por Wi-Fi

Ruta actual: **ESP32 -> Wi-Fi -> Realtime Database -> web**. No necesitas Python
ni una computadora encendida. Arduino IDE sirve para cargar este firmware;
el ESP32 ejecuta el programa por su cuenta. Puedes dejarlo alimentado por USB.

## Cargar desde Arduino IDE

1. Instala la plataforma **esp32 by Espressif Systems**, rama 3.x, en el gestor
   de placas. Selecciona la placa ESP32 que corresponde a tu circuito.
2. En el gestor de bibliotecas instala **ArduinoJson**, versión 7.x.
3. Abre `VigiaESP32/VigiaESP32.ino`.
4. Copia `secrets.example.h` a `secrets.h` en la misma carpeta. Completa el nombre
   y contraseña de una red Wi-Fi 2,4 GHz con Internet y el correo/contraseña del
   usuario ESP32 de Firebase Authentication. No subas `secrets.h` a GitHub.
5. En Firebase activa correo/contraseña, crea el usuario ESP32 y un usuario visor.
   Sustituye sus UID en `database.rules.json` y publica esas reglas.
6. Compila y carga el sketch. Abre el monitor serie a **115200 baudios**.
   El monitor ahora puede permanecer abierto porque no existe un puente USB.
7. Comprueba que aparecen lecturas y el mensaje de sesión Firebase. Revisa
   `devices/esp32-01/current`, `samples` y `events` en Realtime Database.
8. La web inicia sesión con el usuario visor y escucha esas mismas rutas.

## Comportamiento

Se conservan los GPIO del sketch recibido: LM35 34, MQ-7 35, buzzer 27 y relés
25/26, activos en LOW. Umbrales: ADC MQ-7 >= 2200 **o** temperatura >= 47,5 °C.
Cualquiera de las dos condiciones enciende buzzer y ambas bombas; se apagan cuando
ambas lecturas bajan de sus umbrales. No se añade histéresis; se conserva el posible
encendido/apagado repetido si la señal oscila en torno al umbral.

La temperatura usa la calibración aportada por el usuario el 16 de octubre:
promedio de 50 lecturas con analogReadMilliVolts(GPIO 34), separadas por 5 ms,
y fórmula (promedio_mV - 78.05) / 8.627. Una adquisición tarda aproximadamente
250 ms más el tiempo del ADC. Se mantiene el intervalo nominal de control de
un segundo, sin añadir el delay(500) del ejemplo independiente. La calibración
se aplica tanto al control local como a current, samples y máximos de events.
El MQ-7 y los umbrales no cambian. Se debe comprobar la calibración en el montaje
real. El filtrado de datos inválidos para evitar bloquear envíos sigue pendiente.

El control se ejecuta cada segundo. La tarea de red usa HTTPS con certificados
públicos de Google y sincronización de hora por NTP; no desactiva la verificación
TLS. Usa Firebase Authentication REST y renueva el token antes de que expire.
No imprime contraseñas ni tokens. Las credenciales del dispositivo quedan en el
firmware local; las reglas limitan ese usuario al dispositivo indicado.

El estado actual se envía en cada petición exitosa, aproximadamente cada segundo
más el tiempo de la conexión HTTPS. Se guarda una muestra cada 30 segundos y en
cambios de alarma. Un episodio conserva máximos calculados con **todas** las
lecturas locales de un segundo. El máximo final se guarda al terminar el episodio.
En un episodio abierto los máximos se actualizan con cada envío exitoso.

## Desconexiones y límites

Si falla Internet, sensores, buzzer y relés siguen funcionando. Hay una cola RAM
de 64 muestras (unos 32 minutos sin transiciones) y 16 episodios terminados;
además se conserva el episodio activo. Al llenarse una cola se omiten nuevas
entradas de ese tipo y aparece un mensaje en el monitor serie. Los registros
pendientes se reintentan con el mismo ID para no duplicarlos. Se envía siempre
el estado más reciente junto con registros históricos pendientes.

**Las colas no sobreviven a un reinicio o corte de energía.** Si eso es un requisito,
se necesita almacenamiento persistente adicional. Antes de la primera sincronización
NTP las lecturas se conservan en la cola dentro de esos límites; sus fechas se
reconstruyen a partir del reloj monotónico del mismo arranque. Comprueba la precisión
del reloj y la calibración de sensores en tu montaje. El estado del relé no confirma
flujo de agua.

La versión anterior fue compilada y cargada por el usuario con ESP32 core 3.3.12,
y se observaron lecturas reales en la web. Esta actualización de calibración aún
necesita probarse en el circuito: una compilación no valida la precisión del sensor.
La web aún necesita publicación. La configuración pública ya está incluida; cada
instalación necesita sus credenciales locales y reglas con los UID correctos.

## Diagnóstico

- Esperando Wi-Fi: revisa SSID, contraseña, red 2,4 GHz y acceso a Internet.
- Esperando sincronización: la red debe permitir NTP.
- HTTP 400 en Authentication: revisa correo, contraseña, API key y proveedor habilitado.
- HTTP 401/403 al enviar: revisa UID y reglas, o sesión revocada.
- HTTP negativo: conexión HTTPS/DNS o certificado; mantén certificados y core actualizados.

`google_ca.h` se generó desde https://pki.goog/roots.pem (certificados públicos,
14 de octubre de 2026). Incluye raíces vigentes del repositorio oficial de Google.
Referencias: https://firebase.google.com/docs/reference/rest/auth y
https://firebase.google.com/docs/database/rest/save-data y
https://arduinojson.org/v7/api/jsondocument/.
