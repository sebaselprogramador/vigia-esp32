#pragma once
#include <stdint.h>
// Tipos en cabecera para que los prototipos automáticos de Arduino los conozcan.
struct Reading {
  float temperatureC;
  int gasRaw;
  int64_t observedUs;
  bool alarm;
};
struct Sample { Reading reading; char id[40]; };
struct Episode {
  char id[40];
  int64_t startedUs;
  int64_t endedUs;
  float peakTemperatureC;
  int peakGasRaw;
  uint8_t reasons;
};
struct Snapshot { Reading reading; Episode episode; bool hasReading; bool hasEpisode; };
