#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <sys/time.h>
#include <time.h>
#include <esp_timer.h>
#include <esp_system.h>
#include "google_ca.h"
#include "telemetry.h"
#if __has_include("secrets.h")
#include "secrets.h"
#else
#error "Copia secrets.example.h a secrets.h y configura Wi-Fi y el usuario de Firebase."
#endif

#define LM35_PIN 34
#define MQ7_PIN 35
#define BUZZER_PIN 27
#define RELAY1_PIN 25
#define RELAY2_PIN 26
#define RELAY_ACTIVE_LOW true
constexpr int GAS_THRESHOLD = 2200;
constexpr float TEMP_THRESHOLD = 47.5f;
constexpr uint32_t READ_INTERVAL = 1000;
constexpr uint32_t SAMPLE_INTERVAL = 30000;
const char *API_KEY = "AIzaSyA7MoZwbOCRwFw6xMWbLL9pqaFrRsw2k_c";
const char *DATABASE_URL = "https://base-de-datos-proyect-21960-default-rtdb.firebaseio.com";
const char *DEVICE_ID = "esp32-01";

portMUX_TYPE stateMux = portMUX_INITIALIZER_UNLOCKED;
Snapshot sharedState = {};
QueueHandle_t sampleQueue;
QueueHandle_t eventQueue;
bool alertaActiva = false;
Episode activeEpisode = {};
uint32_t lastRead = 0, lastSample = 0, sequence = 0;
uint32_t bootId1, bootId2;

void setRelay(int pin, bool on) {
  digitalWrite(pin, RELAY_ACTIVE_LOW ? (on ? LOW : HIGH) : (on ? HIGH : LOW));
}

void makeId(char *id, size_t size) {
  snprintf(id, size, "%08lx%08lx-%lu", (unsigned long)bootId1,
           (unsigned long)bootId2, (unsigned long)++sequence);
}

Snapshot snapshot() {
  Snapshot result;
  portENTER_CRITICAL(&stateMux);
  result = sharedState;
  portEXIT_CRITICAL(&stateMux);
  return result;
}

// Convierte tiempo monotónico a Unix ms después de sincronizar NTP.
int64_t epochOffsetMs() {
  timeval now;
  gettimeofday(&now, nullptr);
  return (int64_t)now.tv_sec * 1000 + now.tv_usec / 1000 - esp_timer_get_time() / 1000;
}

void writeReading(JsonObject target, const Reading &r, int64_t offset, bool actuators) {
  target["temperatureC"] = r.temperatureC;
  target["gasRaw"] = r.gasRaw;
  target["timestamp"] = offset + r.observedUs / 1000;
  if (actuators) {
    target["alarm"] = r.alarm;
    target["buzzer"] = r.alarm;
    target["pump1"] = r.alarm;
    target["pump2"] = r.alarm;
  }
}

void writeEpisode(JsonObject target, const Episode &episode, int64_t offset) {
  target["startedAt"] = offset + episode.startedUs / 1000;
  if (episode.endedUs) target["endedAt"] = offset + episode.endedUs / 1000;
  target["reason"] = episode.reasons == 3 ? "both" : episode.reasons == 1 ? "gas" : "temperature";
  target["peakTemperatureC"] = episode.peakTemperatureC;
  target["peakGasRaw"] = episode.peakGasRaw;
}

String urlEncode(const String &input) {
  String output;
  for (size_t i = 0; i < input.length(); ++i) {
    const unsigned char c = input[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') output += (char)c;
    else { char hex[4]; snprintf(hex, sizeof(hex), "%%%02X", c); output += hex; }
  }
  return output;
}

int request(const String &url, const char *method, const String &body,
            const char *contentType, String &response) {
  WiFiClientSecure client;
  client.setCACert(GOOGLE_ROOTS);
  client.setHandshakeTimeout(8);
  HTTPClient http;
  http.setConnectTimeout(5000);
  http.setTimeout(8000);
  if (!http.begin(client, url)) return -1;
  http.addHeader("Content-Type", contentType);
  const int status = http.sendRequest(method, body);
  response = status > 0 ? http.getString() : "";
  http.end();
  return status;
}

String idToken, refreshToken;
int64_t tokenDeadlineUs = 0;

bool authenticate() {
  if (idToken.length() && esp_timer_get_time() < tokenDeadlineUs) return true;
  String response, body, url;
  const bool refreshing = refreshToken.length() > 0;
  const char *contentType = refreshing ? "application/x-www-form-urlencoded" : "application/json";
  if (refreshing) {
    url = String("https://securetoken.googleapis.com/v1/token?key=") + API_KEY;
    body = "grant_type=refresh_token&refresh_token=" + urlEncode(refreshToken);
  } else {
    url = String("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=") + API_KEY;
    JsonDocument auth;
    auth["email"] = FIREBASE_EMAIL;
    auth["password"] = FIREBASE_PASSWORD;
    auth["returnSecureToken"] = true;
    serializeJson(auth, body);
  }
  const int status = request(url, "POST", body, contentType, response);
  if (status != 200) {
    Serial.printf("Firebase Authentication HTTP %d. Revisa usuario y acceso por correo.\n", status);
    if (refreshing && (status == 400 || status == 401)) {
      idToken = ""; refreshToken = ""; // reintentar inicio de sesión en la siguiente vuelta
    }
    return false;
  }
  JsonDocument result;
  if (deserializeJson(result, response)) return false;
  idToken = result[refreshing ? "id_token" : "idToken"].as<String>();
  refreshToken = result[refreshing ? "refresh_token" : "refreshToken"].as<String>();
  const long expires = result[refreshing ? "expires_in" : "expiresIn"].as<String>().toInt();
  if (!idToken.length() || !refreshToken.length() || expires <= 60) return false;
  tokenDeadlineUs = esp_timer_get_time() + (int64_t)(expires - 60) * 1000000;
  if (!refreshing) {
    Serial.print("Firebase conectado. UID del ESP32: ");
    Serial.println(result["localId"].as<String>());
  }
  return true;
}

void networkTask(void *) {
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  configTime(0, 0, "time.google.com", "pool.ntp.org");
  uint32_t lastWifiAttempt = millis();
  bool haveSample = false, haveEvent = false;
  Sample pendingSample = {};
  Episode pendingEvent = {};
  for (;;) {
    if (WiFi.status() != WL_CONNECTED) {
      if (millis() - lastWifiAttempt >= 15000) {
        lastWifiAttempt = millis(); WiFi.reconnect();
        Serial.println("Esperando Wi-Fi; el control local sigue activo.");
      }
      vTaskDelay(pdMS_TO_TICKS(1000)); continue;
    }
    if (time(nullptr) < 1700000000) {
      Serial.println("Esperando sincronizacion de hora para HTTPS e historial.");
      vTaskDelay(pdMS_TO_TICKS(3000)); continue;
    }
    if (!authenticate()) { vTaskDelay(pdMS_TO_TICKS(5000)); continue; }
    Snapshot state = snapshot();
    if (!state.hasReading) { vTaskDelay(pdMS_TO_TICKS(100)); continue; }
    if (!haveSample) haveSample = xQueueReceive(sampleQueue, &pendingSample, 0) == pdTRUE;
    if (!haveEvent) haveEvent = xQueueReceive(eventQueue, &pendingEvent, 0) == pdTRUE;
    const int64_t offset = epochOffsetMs();
    JsonDocument patch;
    writeReading(patch["current"].to<JsonObject>(), state.reading, offset, true);
    if (haveSample) writeReading(patch[String("samples/") + pendingSample.id].to<JsonObject>(), pendingSample.reading, offset, false);
    if (state.hasEpisode) writeEpisode(patch[String("events/") + state.episode.id].to<JsonObject>(), state.episode, offset);
    if (haveEvent) writeEpisode(patch[String("events/") + pendingEvent.id].to<JsonObject>(), pendingEvent, offset);
    String payload, response;
    serializeJson(patch, payload);
    const String url = String(DATABASE_URL) + "/devices/" + DEVICE_ID + ".json?auth=" + urlEncode(idToken);
    const int status = request(url, "PATCH", payload, "application/json", response);
    if (status >= 200 && status < 300) {
      haveSample = false; haveEvent = false;
    } else {
      Serial.printf("Envio Firebase pendiente, HTTP %d. Revisa Internet y reglas.\n", status);
      if (status == 401) tokenDeadlineUs = 0;
    }
    // Solo la tarea de red espera; loop() sigue leyendo y controlando cada segundo.
    vTaskDelay(pdMS_TO_TICKS(status >= 200 && status < 300 ? 1000 : 5000));
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RELAY1_PIN, OUTPUT); pinMode(RELAY2_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  setRelay(RELAY1_PIN, false); setRelay(RELAY2_PIN, false);
  analogReadResolution(12);
  sampleQueue = xQueueCreate(64, sizeof(Sample));
  eventQueue = xQueueCreate(16, sizeof(Episode));
  bootId1 = esp_random(); bootId2 = esp_random();
  Serial.println("=== Control local y envio directo ESP32 -> Firebase ===");
  if (!sampleQueue || !eventQueue || xTaskCreate(networkTask, "firebase", 16384, nullptr, 1, nullptr) != pdPASS) {
    Serial.println("No se pudo iniciar la red. El control local permanece activo.");
  }
}

void loop() {
  const uint32_t now = millis();
  if (now - lastRead < READ_INTERVAL) { delay(5); return; }
  lastRead = now;
  const int rawLM35 = analogRead(LM35_PIN);
  // Mantiene la conversion del sketch original. Verifica la calibracion del ADC.
  const float temperatureC = (rawLM35 * (3.3f / 4095.0f)) * 100.0f;
  const int gasRaw = analogRead(MQ7_PIN);
  const bool gasHigh = gasRaw >= GAS_THRESHOLD;
  const bool tempHigh = temperatureC >= TEMP_THRESHOLD;
  const bool alarm = gasHigh || tempHigh;
  const bool changed = alarm != alertaActiva;
  Reading reading = {temperatureC, gasRaw, esp_timer_get_time(), alarm};
  if (changed) {
    digitalWrite(BUZZER_PIN, alarm ? HIGH : LOW);
    setRelay(RELAY1_PIN, alarm); setRelay(RELAY2_PIN, alarm);
  }
  if (alarm) {
    if (!alertaActiva) {
      activeEpisode = {};
      makeId(activeEpisode.id, sizeof(activeEpisode.id));
      activeEpisode.startedUs = reading.observedUs;
      activeEpisode.peakTemperatureC = temperatureC;
      activeEpisode.peakGasRaw = gasRaw;
    }
    activeEpisode.peakTemperatureC = max(activeEpisode.peakTemperatureC, temperatureC);
    activeEpisode.peakGasRaw = max(activeEpisode.peakGasRaw, gasRaw);
    activeEpisode.reasons |= (gasHigh ? 1 : 0) | (tempHigh ? 2 : 0);
  } else if (alertaActiva) {
    activeEpisode.endedUs = reading.observedUs;
    if (!eventQueue || xQueueSend(eventQueue, &activeEpisode, 0) != pdTRUE)
      Serial.println("Cola de eventos llena: este episodio no se guardara en Firebase.");
  }
  alertaActiva = alarm;
  portENTER_CRITICAL(&stateMux);
  sharedState.reading = reading;
  sharedState.episode = activeEpisode;
  sharedState.hasReading = true;
  sharedState.hasEpisode = alarm;
  portEXIT_CRITICAL(&stateMux);
  if (changed || !lastSample || now - lastSample >= SAMPLE_INTERVAL) {
    lastSample = now;
    Sample sample = {}; sample.reading = reading;
    makeId(sample.id, sizeof(sample.id));
    if (!sampleQueue || xQueueSend(sampleQueue, &sample, 0) != pdTRUE)
      Serial.println("Cola de muestras llena: se omite esta muestra historica.");
  }
  Serial.printf("Temp: %.1f C | Gas crudo: %d | Estado: %s\n", temperatureC, gasRaw, alarm ? "ALERTA" : "normal");
}
