#pragma once
// Copia este archivo a secrets.h y completa los datos SOLO en tu computadora.
#define WIFI_SSID "NOMBRE_DE_TU_WIFI"
#define WIFI_PASSWORD "CONTRASENA_DE_TU_WIFI"
#define FIREBASE_EMAIL "CORREO_DEL_USUARIO_ESP32"
#define FIREBASE_PASSWORD "CONTRASENA_DEL_USUARIO_ESP32"
